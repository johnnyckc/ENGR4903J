"""
mapping.py

Pure translation logic: canonical per-timestep records -> hardware visual
parameters. This module knows NOTHING about Simulink's raw output format
(sim_adapter.py's job) and NOTHING about the TXT line format (txt_writer.py's
job). It only knows the visual rules, expressed against the actual protocol
in txt指令.md.

Canonical record shape (one dict per node, keyed by node name from
topology.json), matching what sim_adapter.py produces:

    {
        "PV1":      {"P": 1840.0, "status": "NORMAL"},
        "DESD1":    {"P": 620.0,  "status": "NORMAL", "soc_pct": 58},
        "WT1":      {"P": 310.0,  "status": "NORMAL", "wind_speed_ms": 9.2},
        "Hospital": {"P": 1300.0, "status": "NORMAL"},
        "GRID":     {"P": -450.0, "status": "NORMAL"},   # negative = exporting
        ...
    }

Units: "P" is always kW. sim_adapter.py's Simscape Power Scope export
(Power_<Node> signals) was confirmed to already be in kW by comparing peak
values against topology.json's rated_kw (see topology.json's "_units_note"),
so no conversion happens here or in sim_adapter.py. If a future export ever
sources from a signal genuinely in Watts (e.g. a raw ActualPower_W bus
element), convert at the sim_adapter.py boundary, not here -- this module
should never have to know or care what unit the upstream signal was in.

Sign convention (matches the EMS paper / initAgents_f.m):
    DESD:  positive = discharging, negative = charging
    Grid:  positive = importing (from main grid into microgrid)
    PV/WT/Load/Gen: nonnegative

status values: "NORMAL", "WARNING", "FAULTED", "OFFLINE", "ISOLATED", "SHED".
Per the simplified sandbox rule: anything other than NORMAL/WARNING just
means "turn the light off" -- no graded fault severity beyond that. WARNING
is the one exception: still on, shown in blue (matches the storyline's
"ground saturation" flood-risk-but-not-yet-faulted beats).
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional


ON_STATUSES = {"NORMAL", "WARNING"}
LED_SPEED_MIN, LED_SPEED_MAX = 3, 45     # calibrated against a reference demo script
                                          # (rainstorm_flood_1min_commands.txt): confirmed
                                          # observed speed range on-wire was exactly 3-45,
                                          # not the earlier 1-35 -- see map_feeder's docstring
LED_LENGTH_FIXED = 35    # confirmed constant: every ON line in the reference script had
                         # length == 35 regardless of feeder rated_kw/led_length_max --
                         # length is no longer loading-driven, it's just this fixed value
LED_BRIGHTNESS_MIN = 80  # floor brightness when on, confirmed as the observed minimum
                         # brightness across the reference script's ON lines (range 80-255)

# Discrete color set per txt指令.md -- NOT a continuous hue gradient.
COLOR_RED = 0
COLOR_GREEN = 128
COLOR_BLUE = 160
COLOR_OFF = 0


@dataclass
class LedParams:
    direction: int      # 1 = forward, 0 = reverse (per txt指令.md)
    color: int           # 0=red, 128=green, 160=blue, 0=off (see brightness)
    brightness: int      # 0-255
    length: int          # 0-255, how much of the strip is lit
    speed: int           # 1-35ish, lower = faster (per txt指令.md)


@dataclass
class OledParams:
    battery_pct: int     # 0-100
    voltage1: int        # 0-255
    voltage2: int        # 0-255 (voltage1 + voltage2 = total pack voltage)


@dataclass
class MotorParams:
    speed: int           # 0-255, = round(wind_speed_ms * 8.5), clamped


def _is_on(status: str) -> bool:
    return status in ON_STATUSES


def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


# ---------------------------------------------------------------------------
# Feeder LEDs
# ---------------------------------------------------------------------------

def _node_injection(node_type: str, power_kw: float) -> float:
    """
    Signed 'injection into the network' for a single node, used only as a
    fallback approximation when no direct branch-flow measurement is
    available from Simulink. Sources are positive, sinks are negative.

    Placeholder heuristic, not a real power-flow solution -- ask the
    Simulink teammate whether a per-branch wattmeter signal can be exposed
    instead, which would make this function unnecessary.
    """
    if node_type in ("PV", "WT", "Gen"):
        return power_kw
    if node_type == "Load":
        return -power_kw
    if node_type in ("DESD", "Grid"):
        return power_kw          # already signed per the EMS paper convention
    return 0.0


def map_feeder(feeder_cfg: dict, from_record: dict, from_type: str,
                to_record: Optional[dict] = None, to_type: Optional[str] = None,
                branch_flow_kw: Optional[float] = None) -> LedParams:
    """
    feeder_cfg: topology.json["feeders"][feeder_id]
    from_record / from_type: canonical record entry + type for feeder_cfg["from"]
    to_record / to_type: canonical record entry + type for feeder_cfg["to"].
        Optional for backward compatibility, but should always be supplied --
        without it this falls back to the old one-sided behavior (see below).
    branch_flow_kw: signed kW measured directly on this branch, if Simulink
        can provide one. Preferred over the fallback heuristic.

    A feeder connects two nodes symmetrically -- physically, neither end is
    privileged. "from"/"to" in topology.json exist only to define what
    direction=1 ("forward") MEANS, not to decide whose power counts. An
    earlier version of this function read only from_record's power, which
    made the displayed flow depend on an arbitrary authoring choice (which
    node happened to be written as "from") rather than on anything physical
    -- most visible when both endpoints are the same type (e.g. two
    generators), where the one-sided version could never show flow from
    the "to" side no matter how much it was producing.

    Fixed via an injection-difference model: each endpoint's net injection
    is computed the same way (_node_injection), and the feeder's flow is
    their DIFFERENCE (from's injection minus to's). Swapping from/to in
    config flips the sign of that difference exactly, so the displayed
    result reflects the real gap between the two nodes, not the label.

    Power (kW) vs. current (A): considered using current instead, since
    current is the more electrically rigorous quantity for real branch
    flow (P = V x I, and if node voltages differ, power and current
    rankings can disagree). Kept power deliberately: every other
    quantity in this system (rated_kw, loading, SOC/capacity) is already
    in kW, current alone is ambiguous to compare across nodes at
    different effective voltages without also tracking voltage, and this
    is a human-facing sandbox display where "how many kW" is the
    operationally meaningful question, not "how many amps." Current
    would matter more for a rigorous per-branch analysis, but the LED
    graph already doesn't correspond to real branches (see the decision
    above to keep this heuristic instead of instrumenting real branch
    sensors), so the extra rigor wouldn't be preserved downstream anyway.
    """
    from_status = from_record.get("status", "NORMAL")
    to_status = (to_record or {}).get("status", "NORMAL")

    # NOTE: length_max/led_length_max is INTENTIONALLY UNUSED now -- see
    # LED_LENGTH_FIXED above. topology.json's led_length_max field is kept
    # for now (not deleted from config) but no longer drives this
    # computation. Left in place in case a future revision reintroduces
    # per-feeder physical strip lengths.

    # Off if EITHER endpoint is down -- a feeder can't meaningfully carry
    # power with one side disconnected/faulted, regardless of which side
    # is labeled "from".
    if not (_is_on(from_status) and _is_on(to_status)):
        return LedParams(direction=1, color=COLOR_OFF, brightness=0,
                          length=0, speed=LED_SPEED_MAX)

    if branch_flow_kw is not None:
        flow_kw = branch_flow_kw
    elif to_record is not None and to_type is not None:
        injection_from = _node_injection(from_type, from_record.get("P", 0.0))
        injection_to = _node_injection(to_type, to_record.get("P", 0.0))
        flow_kw = injection_from - injection_to
    else:
        # Backward-compatible fallback when no `to` info is supplied.
        flow_kw = _node_injection(from_type, from_record.get("P", 0.0))

    rated_kw = feeder_cfg["rated_kw"]
    loading = _clamp(abs(flow_kw) / rated_kw, 0.0, 1.0) if rated_kw else 0.0

    direction = 1 if flow_kw >= 0 else 0

    if from_status == "WARNING" or to_status == "WARNING":
        color = COLOR_BLUE
    else:
        color = COLOR_GREEN

    # speed: lower byte = faster per txt指令.md's own quick-reference table.
    # Higher loading -> faster-looking flow -> lower byte.
    speed = int(round(LED_SPEED_MAX - loading * (LED_SPEED_MAX - LED_SPEED_MIN)))

    # brightness: NOW carries the loading-driven value (previously length
    # did). Floored so it never looks fully dark while still nominally on.
    brightness = int(round(LED_BRIGHTNESS_MIN + loading * (255 - LED_BRIGHTNESS_MIN)))

    # length: NOW a fixed constant whenever the feeder is on -- confirmed
    # against real reference data to no longer vary with loading or
    # per-feeder led_length_max.
    length = LED_LENGTH_FIXED

    return LedParams(direction=direction, color=color, brightness=brightness,
                      length=length, speed=speed)


# ---------------------------------------------------------------------------
# DESD OLEDs
# ---------------------------------------------------------------------------

def map_desd_oled(record: dict) -> Optional[OledParams]:
    """Returns None when the OLED should go dark (offline/isolated/faulted)."""
    status = record.get("status", "NORMAL")
    if not _is_on(status):
        return None

    soc = int(round(_clamp(record.get("soc_pct", 0), 0, 100)))

    # Voltage split: v1 + v2 = total pack voltage, v1 capped at 255.
    # Total voltage isn't in the canonical record by default -- if the
    # Simulink model exposes a real pack voltage, wire it through here
    # instead of this placeholder nominal value.
    total_voltage = int(record.get("voltage_v", 380))
    v1 = min(255, total_voltage)
    v2 = max(0, total_voltage - v1)

    return OledParams(battery_pct=soc, voltage1=v1, voltage2=v2)


# ---------------------------------------------------------------------------
# Wind turbine motor
# ---------------------------------------------------------------------------

def map_wind_turbine(record: dict, node_cfg: dict) -> MotorParams:
    """
    txt指令.md's formula is speed = wind_speed_ms * 8.5, which needs an
    actual wind-speed signal -- NOT Result_WTAgent1 (dispatched power).
    If the canonical record carries "wind_speed_ms" (from the Simulink
    renewable-profile-generation module, which does take wind speed as an
    input), use that directly. Otherwise fall back to a cube-root
    approximation from the power fraction, which is a rough visual stand-in
    only -- flag this with the Simulink teammate rather than trusting it.
    """
    status = record.get("status", "NORMAL")
    if not _is_on(status):
        return MotorParams(speed=0)

    wind_speed_ms = record.get("wind_speed_ms")
    if wind_speed_ms is None:
        rated_kw = node_cfg.get("rated_kw", 0)
        rated_wind = node_cfg.get("rated_wind_speed_ms", 12)
        fraction = _clamp(record.get("P", 0.0) / rated_kw, 0.0, 1.0) if rated_kw else 0.0
        wind_speed_ms = (fraction ** (1 / 3)) * rated_wind   # rough P ~ v^3 inversion

    speed_byte = int(round(_clamp(wind_speed_ms * 8.5, 0, 255)))
    return MotorParams(speed=speed_byte)


# ---------------------------------------------------------------------------
# IO / buildings bitmask (single IO91 device, two bytes per txt指令.md)
# ---------------------------------------------------------------------------

def map_io_bitmask(records: dict, topology: dict) -> tuple[int, int]:
    """
    records: full canonical record dict, keyed by node name
    topology: parsed topology.json

    Returns (arg3, arg4): buildings 1-8 bitmask, buildings 9-16 bitmask.
    """
    arg3, arg4 = 0, 0

    for node_name, node_cfg in topology["nodes"].items():
        bit = node_cfg.get("io_bit")
        if bit is None:
            continue

        record = records.get(node_name, {})
        status = record.get("status", "NORMAL")
        if not _is_on(status):
            continue

        if bit < 8:
            arg3 |= (1 << bit)
        else:
            arg4 |= (1 << (bit - 8))

    return arg3, arg4