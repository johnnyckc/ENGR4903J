"""
txt_writer.py

Last stage of the pipeline. Converts mapping.py's per-device parameter
objects into lines of the LabVIEW TXT command format:

    设备ID arg3 arg4 arg5 arg6 arg7 | 等待时间(ms)

This module does NOT open a socket -- per txt指令.md, LabVIEW itself parses
each line with one Scan From String call and sends the UDP frame. Our job
ends at producing a correct, well-formed .txt file.

Pipeline recap:
    sim_adapter.py   -> canonical per-hour records (power + status)
    mapping.py       -> per-device visual parameters (LedParams, etc.)
    txt_writer.py    -> formatted TXT lines, grouped into timestep blocks
"""

from __future__ import annotations
import re
from pathlib import Path
from typing import Iterable

import mapping
import sim_adapter


def _strip_device_prefix(device_id: str) -> str:
    """
    Strips a leading alphabetic device-type prefix, keeping just the
    numeric identifier -- e.g. "LED101" -> "101", "SCREEN51" -> "51",
    "WT81" -> "81", "IO91" -> "91".

    Only affects the OUTPUT line -- topology.json's device_id fields keep
    their original prefixed form (useful for readability when reading the
    config), this only strips it at the point the .txt line is written.
    """
    return re.sub(r"^[A-Za-z]+", "", device_id)


def _line(device_id: str, a3, a4, a5, a6, a7) -> str:
    return f"{_strip_device_prefix(device_id)} {a3} {a4} {a5} {a6} {a7}"


def format_led_line(device_id: str, p: mapping.LedParams) -> str:
    return _line(device_id, p.direction, p.color, p.brightness, p.length, p.speed)


def format_screen_line(device_id: str, p: mapping.OledParams) -> str:
    return _line(device_id, p.battery_pct, p.voltage1, p.voltage2, 0, 0)


def format_wt_line(device_id: str, p: mapping.MotorParams) -> str:
    return _line(device_id, p.speed, 0, 0, 0, 0)


def format_io_line(device_id: str, arg3: int, arg4: int) -> str:
    return _line(device_id, arg3, arg4, 0, 0, 0)


def build_timestep_block(command_lines: list[str], wait_ms: int,
                          comment: str | None = None) -> list[str]:
    """
    Per txt指令.md: every line in a timestep uses '| 0' (send immediately)
    except the last, which carries the real wait time -- that's what makes
    all commands in the step land together, then hold for wait_ms before
    the next step.
    """
    if not command_lines:
        return [f"# {comment}"] if comment else []

    out = [f"# {comment}"] if comment else []
    for line in command_lines[:-1]:
        out.append(f"{line} | 0")
    out.append(f"{command_lines[-1]} | {wait_ms}")
    return out


def render_hour(records: dict, topology: dict, wait_ms: int,
                 comment: str | None = None) -> list[str]:
    """
    records: canonical record dict for one hour, as produced by
        sim_adapter.build_day_records (includes "_feeders" sub-dict).
    topology: parsed topology.json
    wait_ms: how long the sandbox holds this hour's state before the next
        one -- this is your demo pacing knob (e.g. 8000 for a fast runthrough,
        60000 for a slower one), NOT a real-time simulation clock.

    Returns a list of TXT lines (including the leading comment line) for
    this single hour, ready to be joined and appended to the output file.
    """
    command_lines: list[str] = []

    # Feeders (LEDs)
    for feeder_id, feeder_cfg in topology["feeders"].items():
        from_name = feeder_cfg["from"]
        to_name = feeder_cfg["to"]
        from_record = records.get(from_name, {})
        to_record = records.get(to_name, {})
        from_type = topology["nodes"].get(from_name, {}).get("type", "")
        to_type = topology["nodes"].get(to_name, {}).get("type", "")

        feeder_record = records.get("_feeders", {}).get(feeder_id, {})
        # Feeder-level fault status (e.g. the line itself tripped) overrides
        # the "from" endpoint's own status for this LED specifically. (The
        # "to" endpoint's own status, separately, already gates on/off via
        # map_feeder's own from/to check below -- this override only
        # models a fault on the line itself, not on either endpoint.)
        effective_from_record = dict(from_record)
        if feeder_record.get("status") not in (None, "NORMAL"):
            effective_from_record["status"] = feeder_record["status"]

        led_params = mapping.map_feeder(
            feeder_cfg, effective_from_record, from_type,
            to_record=to_record, to_type=to_type,
            branch_flow_kw=feeder_record.get("branch_flow_kw"),
        )
        command_lines.append(format_led_line(feeder_cfg["device_id"], led_params))

    # DESD OLEDs
    for node_name, node_cfg in topology["nodes"].items():
        if node_cfg["type"] != "DESD":
            continue
        oled_params = mapping.map_desd_oled(records.get(node_name, {}))
        if oled_params is not None:
            command_lines.append(format_screen_line(node_cfg["device_id"], oled_params))
        # else: OLED goes dark -- per txt指令.md there's no explicit "off"
        # frame shown in the examples; sending nothing leaves it at its
        # last state. If the hardware needs an explicit blank frame instead,
        # add one here once confirmed with the hardware team.

    # Wind turbine
    for node_name, node_cfg in topology["nodes"].items():
        if node_cfg["type"] != "WT":
            continue
        motor_params = mapping.map_wind_turbine(records.get(node_name, {}), node_cfg)
        command_lines.append(format_wt_line(node_cfg["device_id"], motor_params))

    # IO / buildings (single device, two bitmask bytes)
    arg3, arg4 = mapping.map_io_bitmask(records, topology)
    command_lines.append(format_io_line(topology["io_device"]["device_id"], arg3, arg4))

    return build_timestep_block(command_lines, wait_ms, comment)


def render_day(day_key: str, hourly_records: Iterable[tuple[int, dict]],
               topology: dict, wait_ms_per_hour: int = 8000) -> list[str]:
    """
    hourly_records: iterable of (hour, canonical_record), e.g. from
        sim_adapter.build_day_records(...).
    """
    lines = [f"# Day {day_key}"]
    for hour, record in hourly_records:
        lines.append("")
        lines.extend(render_hour(
            record, topology, wait_ms_per_hour,
            comment=f"Day {day_key}, hour {hour:02d}:00",
        ))
    return lines


def write_txt_file(lines: list[str], out_path: str | Path) -> None:
    Path(out_path).write_text("\n".join(lines) + "\n", encoding="utf-8")


DEFAULT_TOLERANCES = {
    "led_brightness": 10,   # 0-255 scale
    "led_length": 0,        # currently a fixed constant when on; any change matters
    "led_speed": 2,
    "oled_battery_pct": 3,  # percent
    "oled_voltage": 5,      # volts (post byte-split)
    "motor_speed": 3,
}


def _params_within_tolerance(kind: str, old, new, tol: dict) -> bool:
    """
    True if `new` is close enough to `old` that re-emitting this device
    isn't worth it. Categorical fields (direction, color, IO bitmask)
    always require an EXACT match -- there's no "slightly different"
    direction or bitmask. Continuous fields (brightness/length/speed/
    battery/voltage) tolerate drift up to the configured threshold, since
    real physical data fluctuates constantly and exact equality almost
    never holds hour to hour (see project history: only 42.5% size
    reduction with exact-match delta compression against real data).
    """
    if old is None or new is None:
        return old is new

    if kind == "led":
        if old.direction != new.direction or old.color != new.color:
            return False
        return (abs(old.brightness - new.brightness) <= tol["led_brightness"]
                and abs(old.length - new.length) <= tol["led_length"]
                and abs(old.speed - new.speed) <= tol["led_speed"])

    if kind == "oled":
        return (abs(old.battery_pct - new.battery_pct) <= tol["oled_battery_pct"]
                and abs(old.voltage1 - new.voltage1) <= tol["oled_voltage"]
                and abs(old.voltage2 - new.voltage2) <= tol["oled_voltage"])

    if kind == "motor":
        return abs(old.speed - new.speed) <= tol["motor_speed"]

    if kind == "io":
        return old == new  # bitmask -- exact only, a single bit is meaningful

    return old == new


def _format_device_line(kind: str, device_id: str, params) -> str:
    if kind == "led":
        return format_led_line(device_id, params)
    if kind == "oled":
        return format_screen_line(device_id, params)
    if kind == "motor":
        return format_wt_line(device_id, params)
    if kind == "io":
        arg3, arg4 = params
        return format_io_line(device_id, arg3, arg4)
    raise ValueError(f"Unknown device kind: {kind}")


def render_scenario_compressed(topology: dict, timeline: dict, results_dir: str | Path,
                                total_demo_ms: int = 60000,
                                tolerances: dict | None = None) -> list[str]:
    """
    Sparse, delta-based rendering across the ENTIRE multi-day scenario,
    proportionally compressed into total_demo_ms.

    Unlike render_day/render_hour (which emit every device's state every
    hour), this only emits a line for a device when its parameters
    changed by MORE THAN THE CONFIGURED TOLERANCE since the last EMITTED
    tick (not the last computed tick -- comparing against last-emitted
    means small per-hour drift accumulates until it crosses the
    threshold, rather than resetting every hour). Skipped ticks
    accumulate their duration into the next emitted block's wait time,
    so total playback time still matches total_demo_ms regardless of
    sparsity. See DEFAULT_TOLERANCES for the default thresholds --
    override via the `tolerances` dict to tune how sparse the output is.

    NOTE ON GRANULARITY: our canonical records are hourly (24/day). If a
    reference script describes sub-hourly events (e.g. "10:15", "10:20"),
    this function cannot reproduce that finer timing -- it can only
    detect and emit changes at whole-hour resolution.
    """
    tol = dict(DEFAULT_TOLERANCES)
    if tolerances:
        tol.update(tolerances)

    day_keys = sorted(timeline["days"], key=int)
    all_ticks: list[tuple[str, int, dict]] = []
    for day_key in day_keys:
        for hour, record in sim_adapter.build_day_records(day_key, topology, timeline, results_dir):
            all_ticks.append((day_key, hour, record))

    if not all_ticks:
        return []

    ms_per_tick = total_demo_ms / len(all_ticks)

    lines: list[str] = []
    last_emitted: dict[str, tuple[str, object]] = {}
    pending_wait = 0.0

    for day_key, hour, record in all_ticks:
        current = _compute_all_device_params(topology, record)
        changed: dict[str, tuple[str, object]] = {}
        for device_id, (kind, params) in current.items():
            if params is None:
                continue  # dark/hold-last-state device -- never triggers a re-emit
            prev = last_emitted.get(device_id)
            if prev is None or not _params_within_tolerance(kind, prev[1], params, tol):
                changed[device_id] = (kind, params)

        pending_wait += ms_per_tick

        if changed:
            lines.append(f"# Day {day_key}, hour {hour:02d}:00")
            changed_items = list(changed.items())
            for device_id, (kind, params) in changed_items[:-1]:
                lines.append(f"{_format_device_line(kind, device_id, params)} | 0")
            last_device_id, (last_kind, last_params) = changed_items[-1]
            lines.append(f"{_format_device_line(last_kind, last_device_id, last_params)} "
                         f"| {int(round(pending_wait))}")
            lines.append("")
            pending_wait = 0.0
            last_emitted.update(changed)

    return lines


def _compute_all_device_params(topology: dict, record: dict) -> dict[str, tuple[str, object]]:
    """
    Computes every device's RAW parameters (not yet formatted to a
    string) for one hour's canonical record, keyed by device_id.
    Returns (kind, params) tuples so callers can do tolerance-aware
    comparison before deciding whether to format+emit a line at all --
    formatting to a string too early would force exact-string comparison,
    which is what caused the poor sparsity in the first version of this
    function (see project history).
    """
    result: dict[str, tuple[str, object]] = {}

    for feeder_id, feeder_cfg in topology["feeders"].items():
        from_name = feeder_cfg["from"]
        to_name = feeder_cfg["to"]
        from_record = record.get(from_name, {})
        to_record = record.get(to_name, {})
        from_type = topology["nodes"].get(from_name, {}).get("type", "")
        to_type = topology["nodes"].get(to_name, {}).get("type", "")

        feeder_record = record.get("_feeders", {}).get(feeder_id, {})
        effective_from_record = dict(from_record)
        if feeder_record.get("status") not in (None, "NORMAL"):
            effective_from_record["status"] = feeder_record["status"]

        led_params = mapping.map_feeder(
            feeder_cfg, effective_from_record, from_type,
            to_record=to_record, to_type=to_type,
            branch_flow_kw=feeder_record.get("branch_flow_kw"),
        )
        result[feeder_cfg["device_id"]] = ("led", led_params)

    for node_name, node_cfg in topology["nodes"].items():
        if node_cfg["type"] != "DESD":
            continue
        oled_params = mapping.map_desd_oled(record.get(node_name, {}))
        result[node_cfg["device_id"]] = ("oled", oled_params)  # may be None

    for node_name, node_cfg in topology["nodes"].items():
        if node_cfg["type"] != "WT":
            continue
        motor_params = mapping.map_wind_turbine(record.get(node_name, {}), node_cfg)
        result[node_cfg["device_id"]] = ("motor", motor_params)

    arg3, arg4 = mapping.map_io_bitmask(record, topology)
    result[topology["io_device"]["device_id"]] = ("io", (arg3, arg4))

    return result


def write_compressed_scenario(topology_path: str | Path, timeline_path: str | Path,
                               results_dir: str | Path, out_path: str | Path,
                               total_demo_ms: int = 60000) -> None:
    """Entry point mirroring the __main__ block below, callable directly."""
    topology = sim_adapter.load_topology(topology_path)
    timeline = sim_adapter.load_timeline(timeline_path)
    lines = render_scenario_compressed(topology, timeline, results_dir, total_demo_ms)
    write_txt_file(lines, out_path)


if __name__ == "__main__":
    import sys

    if len(sys.argv) == 5:
        topo_path, timeline_path, results_dir, out_path = sys.argv[1:5]
        topology = sim_adapter.load_topology(topo_path)
        timeline = sim_adapter.load_timeline(timeline_path)

        all_lines: list[str] = []
        for day_key in sorted(timeline["days"], key=int):
            day_records = sim_adapter.build_day_records(day_key, topology, timeline, results_dir)
            all_lines.extend(render_day(day_key, day_records, topology))
            all_lines.append("")

        write_txt_file(all_lines, out_path)
        print(f"Wrote {out_path}")

    elif len(sys.argv) == 6:
        topo_path, timeline_path, results_dir, out_path, total_ms_str = sys.argv[1:6]
        write_compressed_scenario(topo_path, timeline_path, results_dir, out_path,
                                   total_demo_ms=int(total_ms_str))
        print(f"Wrote {out_path} (compressed to {total_ms_str}ms)")

    else:
        print("Usage:")
        print("  Dense (original):    python3 txt_writer.py topo.json timeline.json Output out.txt")
        print("  Compressed (sparse): python3 txt_writer.py topo.json timeline.json Output out.txt 60000")
