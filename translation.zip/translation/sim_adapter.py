"""
sim_adapter.py

The only module that knows Simulink's actual output shape. Converts:

    Power_<Node>, SOCMonitorDESD<n>, VScopeFrom_DESD<n>, IScopeFrom_<Node>
        (every one of these is now a plain [1440x1] double array -- see
        "WHY THIS LOOKS THE WAY IT DOES" below)
        +
    a hand-authored storyline fault/status timeline (JSON, see schema below)
        =
    canonical per-hour records, ready for mapping.py.

Nothing downstream of this file should ever touch a raw Simulink array or
the timeline JSON directly -- if the export format changes again, this is
the only file that needs to change.

--------------------------------------------------------------------------
WHY THIS LOOKS THE WAY IT DOES (read before changing anything below)

This is the THIRD version of this module's data-handling approach:

  v1: Read Result_<AgentName> [1x24] signals -- turned out to be config
      placeholders, never populated during a run.
  v2: Read Power_*/SOCMonitorDESD*/VScopeFrom_DESD* taps at native solver
      resolution (thousands of irregular samples), inferred a 24-hour
      "tail window" from tout/signal timestamps, and resampled it down
      via bucket-averaging (see project history for why averaging, not
      2-point interpolation, was the right call once ~60 samples/hour
      were confirmed to actually be available).
  v3 (this version): update_tap_settings.m set every tap's "Limit data
      points to last" to 1440 and "Save format" to Array directly in
      Simulink. This moves the truncation that v2 did in Python (inferring
      the real dispatch window from tout) into the model itself -- each
      tap now natively keeps only its last 1440 logged samples. 1440 = 24
      hours x 60 samples/hour, matching initAgents_f.m's own
      Uncertainty_Time cadence.

WHAT THIS MEANS FOR THE CODE BELOW: no more tout, no more per-signal time
vectors, no more interpolation. Every array is assumed to be exactly
samples_per_day (1440) samples, uniformly covering the real 24-hour
dispatch day, in order. Getting an hourly value is just: reshape into
(hourly_steps, samples_per_hour) and take the mean of each row -- the same
bucket-averaging principle as v2, just simpler because Simulink now
guarantees the array is already the right length and (assumed) evenly
spaced, instead of Python having to infer that from timestamps.

THE ONE THING THIS ASSUMES BUT DOES NOT YET VERIFY: that "the last 1440
logged samples" really do land at a consistent ~60s cadence spanning
close to a real 24-hour window, the way Uncertainty_Time does. v2's tail
window was validated against real data before being trusted (SOC frozen
until 98 seconds from the predicted boundary). This version has NOT had
an equivalent independent check yet, because SaveFormat=Array throws away
per-sample timing entirely -- there's nothing left to check it against
after the fact. If hourly values ever look physically wrong (e.g. a PV
curve that doesn't look like sunrise-to-sunset), this assumption is the
first thing to revisit -- see topology.json's "_tail_window_note".

--------------------------------------------------------------------------
Storyline timeline JSON schema (hand-authored, one file per demo run):

{
  "days": {
    "1": {
      "results_file": "results_day1.mat",
      "events": [
        {"hour": 0,  "target": "ALL",   "status": "NORMAL"},
        {"hour": 10, "target": "PV2",   "status": "OFFLINE"}
      ]
    }
  }
}

A target of "F<feeder_id>" (e.g. "F114") applies to a feeder edge; any other
target string must match a node name in topology.json. Status persists from
the declared hour forward until a later event overrides it for that target.
"ALL" resets every node and feeder to the given status before other events
for that hour are applied.
"""

from __future__ import annotations
import json
from pathlib import Path
from typing import Iterator

import numpy as np

try:
    from scipy.io import loadmat
except ImportError:
    loadmat = None


def load_topology(path: str | Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_timeline(path: str | Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _load_mat(path: str | Path) -> dict:
    if loadmat is None:
        raise RuntimeError(
            "scipy is required to read Simulink .mat exports: pip install scipy"
        )
    raw = loadmat(path, squeeze_me=True, struct_as_record=False)
    return {k: v for k, v in raw.items() if not k.startswith("__")}


def _reshape_to_hourly(raw_values, samples_per_day: int, hourly_steps: int,
                        signal_name: str) -> np.ndarray:
    """
    Reshapes a flat [samples_per_day] array into [hourly_steps] hourly
    values by averaging each hour's block of samples.

    Requires an EXACT length match -- fails loudly rather than silently
    truncating/padding mismatched data, since a length mismatch means the
    MaxDataPoints=1440 assumption (see module docstring) didn't hold for
    this particular signal, and that's worth knowing about immediately
    rather than producing quietly-wrong hourly values.
    """
    values = np.asarray(raw_values).flatten()
    if values.size != samples_per_day:
        raise RuntimeError(
            f"'{signal_name}' has {values.size} samples, expected exactly "
            f"{samples_per_day} (topology.json's sim.samples_per_day). "
            f"Check that update_tap_settings.m's MaxDataPoints=1440 was "
            f"actually applied and the model was re-run/re-exported after."
        )
    if samples_per_day % hourly_steps != 0:
        raise RuntimeError(
            f"samples_per_day ({samples_per_day}) is not evenly divisible "
            f"by hourly_steps_per_day ({hourly_steps})."
        )
    samples_per_hour = samples_per_day // hourly_steps
    return values.reshape(hourly_steps, samples_per_hour).mean(axis=1)


def _resolve_status(timeline_events: list[dict], hour: int, target: str) -> str:
    """
    Latest event at or before `hour` whose target is `target` or "ALL"
    wins. Defaults to NORMAL if nothing has fired yet.
    """
    status = "NORMAL"
    for event in sorted(timeline_events, key=lambda e: e["hour"]):
        if event["hour"] > hour:
            break
        if event["target"] in (target, "ALL"):
            status = event["status"]
    return status


def _resample_all(mat_data: dict, topology: dict, signal_key: str) -> dict[str, np.ndarray]:
    """Resample every node's given signal type (power/soc/voltage/current)."""
    samples_per_day = topology["sim"]["samples_per_day"]
    hourly_steps = topology["sim"]["hourly_steps_per_day"]
    result: dict[str, np.ndarray] = {}
    for node_name, node_cfg in topology["nodes"].items():
        signal_name = node_cfg.get(signal_key)
        if signal_name is None or signal_name not in mat_data:
            continue
        result[node_name] = _reshape_to_hourly(
            mat_data[signal_name], samples_per_day, hourly_steps, signal_name)
    return result


def build_day_records(day_key: str, topology: dict, timeline: dict,
                       results_dir: str | Path) -> Iterator[tuple[int, dict]]:
    """
    Yields (hour, canonical_record) for every hour of the given day.
    canonical_record is keyed by node name, each value a dict with at
    least "P" and "status", plus "soc_pct"/"voltage_v"/"I_A" for nodes
    where those signals are available.

    Raises RuntimeError if the (weak, see check_ready) readiness check
    fails -- callers should treat that as "do not send anything for this
    day yet", not as an error to silently swallow.
    """
    day_cfg = timeline["days"][day_key]
    mat_path = Path(results_dir) / day_cfg["results_file"]
    mat_data = _load_mat(mat_path)

    if not check_ready(mat_data, topology):
        raise RuntimeError(
            f"Day {day_key}: readiness check failed -- no signal was found "
            f"with the expected samples_per_day length. Outputs are not "
            f"valid to translate yet."
        )

    hourly_steps = topology["sim"]["hourly_steps_per_day"]
    events = day_cfg["events"]

    resampled_power = _resample_all(mat_data, topology, "power_signal")
    resampled_soc = _resample_all(mat_data, topology, "soc_signal")
    resampled_voltage = _resample_all(mat_data, topology, "voltage_signal")
    resampled_current = _resample_all(mat_data, topology, "current_signal")

    for hour in range(hourly_steps):
        record = {}
        for node_name in topology["nodes"]:
            power_kw = float(resampled_power[node_name][hour]) if node_name in resampled_power else 0.0
            status = _resolve_status(events, hour, node_name)
            entry = {"P": power_kw, "status": status}

            if node_name in resampled_soc:
                entry["soc_pct"] = float(resampled_soc[node_name][hour])
            if node_name in resampled_voltage:
                entry["voltage_v"] = float(resampled_voltage[node_name][hour])
            if node_name in resampled_current:
                entry["I_A"] = float(resampled_current[node_name][hour])

            record[node_name] = entry

        # Feeder status resolved the same way, keyed as "F<id>". Feeder
        # branch-flow measurement is still not exposed by Simulink
        # (unchanged) -- mapping.py's node-injection heuristic is still
        # in effect for feeder LEDs.
        feeder_records = {}
        for feeder_id in topology["feeders"]:
            feeder_status = _resolve_status(events, hour, f"F{feeder_id}")
            feeder_records[feeder_id] = {
                "status": feeder_status,
                "branch_flow_kw": None,
            }

        record["_feeders"] = feeder_records
        yield hour, record


def iterate_scenario(topology_path: str | Path, timeline_path: str | Path,
                      results_dir: str | Path) -> Iterator[tuple[str, int, dict]]:
    """Top-level entry point: yields (day_key, hour, canonical_record)."""
    topology = load_topology(topology_path)
    timeline = load_timeline(timeline_path)

    for day_key in sorted(timeline["days"], key=int):
        for hour, record in build_day_records(day_key, topology, timeline, results_dir):
            yield day_key, hour, record


if __name__ == "__main__":
    import sys

    topo_path, timeline_path, results_dir = sys.argv[1], sys.argv[2], sys.argv[3]
    for day, hour, record in iterate_scenario(topo_path, timeline_path, results_dir):
        print(f"day={day} hour={hour:02d} "
              f"Hospital={record['Hospital']} "
              f"F114={record['_feeders']['114']}")
