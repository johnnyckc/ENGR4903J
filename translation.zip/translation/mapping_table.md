# Simulation-to-Hardware Mapping Table
 
Reference for `mapping.py`. Source data is now the Simscape Power Scope
export (`Power_<Node>`, `SOCMonitorDESD<n>`), resampled to 24 hourly points
by `sim_adapter.py` — see that file's docstring for the tail-window
truncation and resampling logic. All power values below are kW.
 
## Feeder LEDs (`map_feeder`)
 
One LED strip per feeder edge in `topology.json["feeders"]`. Driven by the
feeder's `from` node's status and power (or a direct branch-flow reading,
not currently available — see below).
 
| Condition | Direction | Color | Brightness | Length | Speed |
|---|---|---|---|---|---|
| `from` node status is `OFFLINE`/`FAULTED`/`ISOLATED`/`SHED` | forward (1) | off | 0 | 0 | max (35, slowest) |
| Status `NORMAL`, flow ≥ 0 | forward (1) | green (128) | 255 | scaled by loading, floor 15% | scaled by loading |
| Status `NORMAL`, flow < 0 | reverse (0) | green (128) | 255 | scaled by loading, floor 15% | scaled by loading |
| Status `WARNING` | as above | **blue (160)** instead of green | 255 | scaled by loading | scaled by loading |
 
- **Loading** = `abs(flow_kw) / feeder_rated_kw`, clamped to [0, 1].
- **Length** = `(0.15 + loading × 0.85) × led_length_max` — never fully collapses while on.
- **Speed** = `35 − loading × (35 − 1)` — higher loading moves faster (lower byte = faster, per hardware spec).
- **Flow source**: `branch_flow_kw` if Simulink provides one directly (still not exposed); otherwise a heuristic (`_node_injection`) infers it from the `from` node's type and power: PV/WT/Gen sources are positive, Loads are negated, DESD/Grid use their own signed convention as-is.
## DESD Battery OLEDs (`map_desd_oled`)
 
One per DESD node (`DESD1`–`DESD4`), using `soc_pct` from `sim_adapter.py`'s
resampled `SOCMonitorDESD*` output.
 
| Condition | Output |
|---|---|
| Status not `NORMAL`/`WARNING` | Screen goes dark (`None` — no frame sent, holds last state) |
| Status `NORMAL`/`WARNING` | `battery_pct` = `soc_pct` clamped to [0, 100]; `voltage1/voltage2` split from a nominal 380V pack total (placeholder — no real pack-voltage signal available yet) |
 
## Wind Turbine Motor (`map_wind_turbine`)
 
| Condition | Output |
|---|---|
| Status not `NORMAL`/`WARNING` | `speed = 0` |
| `wind_speed_ms` available in record | `speed = clamp(wind_speed_ms × 8.5, 0, 255)` |
| No wind speed available (current default) | Approximated via `(P / rated_kw)^(1/3) × rated_wind_speed_ms`, then same formula — a rough stand-in, not a real measurement |
 
## Building/IO Bitmask (`map_io_bitmask`)
 
Single device (`IO91`), two bytes (`arg3` = bits 0–7, `arg4` = bits 8–15).
Each node with an `io_bit` in `topology.json` sets its bit when status is
`NORMAL`/`WARNING`, leaves it clear otherwise.
 
| Bit | Node | Byte |
|---|---|---|
| 0 | Hospital | arg3 |
| 1 | CommCenter | arg3 |
| 2 | ResArea1 | arg3 |
| 3 | ResArea2 | arg3 |
| 4 | PV1 | arg3 |
| 5 | PV2 | arg3 |
| 6 | Gen1 | arg3 |
| 7 | Gen2 | arg3 |
| 8 | DESD1 | arg4 |
| 9 | DESD2 | arg4 |
| 10 | DESD3 | arg4 |
| 11 | DESD4 | arg4 |
| 12 | WT1 | arg4 |
| 13 | GRID | arg4 |
 
## Known gaps (carried over, not fixed by this update)
 
- **Branch-flow measurement**: deliberately NOT pursued. Feeders still use
  the `_node_injection` heuristic. Investigated instrumenting the real
  Simscape branches with in-line Current Sensors, but the LED feeder graph
  in `topology.json` was found not to match the actual circuit wiring (it's
  a stylized layout for the physical sandbox display, not a literal trace
  of the Simscape branches) — real branch measurements wouldn't correspond
  to the edges being displayed, so measuring them wouldn't actually improve
  accuracy without first redesigning the LED-edge-to-branch correspondence.
  The heuristic is exact for true leaf nodes (single connecting wire, so
  100% of that node's power must flow through it by KCL) and is weakest for
  the `"backbone"`/`"main_grid_tie"` feeders, which likely represent
  aggregate flow rather than one physical branch by design.
- **Battery pack voltage**: OLED voltage split still uses a placeholder
  nominal 380V; no real pack-voltage signal available.
- **ActualPower_W** (the second SOC Monitor bus element): not currently
  captured in the export — only `SOC_percent` is available (see
  `topology.json`'s `"_soc_note"`).
- **Wind speed**: `WT1`'s motor speed still falls back to the cube-root
  power approximation; no direct wind-speed signal has been wired through
  from the renewable-profile module yet.
 
